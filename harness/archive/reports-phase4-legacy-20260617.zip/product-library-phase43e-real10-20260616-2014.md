﻿# Product Library Phase 4-3E - RECENT_30D maxActivities=10 Real Backfill Report

- Date: 2026-06-16 20:14 CST
- Phase: 4-3E
- Scope: **RECENT_30D maxActivities=10 real backfill async** (dryRun=false, confirm=true)
- Real async jobId: \product-backfill-de8f225a-e8b5-43d6-a848-24e6668d1053\
- Status: **PASS** (all 9 automated checks green, business data growth reasonable)

## 1. Pre-checks (19:53)

| Item | Result |
|---|---|
| RUNNING job | 0 |
| Redis backfill lock | 0 |
| backend health | UP |

## 2. Real backfill execution

\POST /api/product-sync/admin/backfill-activity-products/async\

Body:
\\\json
{
  "scope": "RECENT_30D",
  "maxActivities": 10,
  "pageSize": 20,
  "maxPagesPerActivity": 1000,
  "maxRowsPerActivity": 50000,
  "dryRun": false,
  "confirm": true,
  "displayRefreshMode": "DEFERRED"
}
\\\

Submit: HTTP 200, 0.04s
Async jobId: \product-backfill-de8f225a-e8b5-43d6-a848-24e6668d1053\
Status on submit: RUNNING

## 3. Polling (30s interval, ~20 min total)

| t | status | scanned | succ | fail | apiRows | ins | upd | stopStats | finished |
|---|---|---|---|---|---|---|---|---|---|
| +30s ~ +930s | RUNNING | 0 | 0 | 0 | 0 | 0 | 0 | {} | (still going) |
| +960s (16 min) | **SUCCESS** | 10 | 10 | 0 | 26272 | 23692 | 1682 | {DONE_NO_MORE:10} | 20:13:22 |

started: 2026-06-16T11:53:37.782446Z
finished: 2026-06-16T12:13:22.695275Z
duration: 1185s (19 min 45 sec)

Note: scanned=0 during 0-930s reflects the Phase 4-3A limitation (job_log
flushes only on job finish). The 19m 45s duration vs 4-3C dry-run 10's
3m 11s is consistent with real backfill doing:
- Lock acquisition (PRODUCT_BACKFILL_GLOBAL)
- Activity-level locks (acquire per activity)
- DB writes (per activity batch in transaction)
- Trigger deferred display refresh

## 4. Verification (post-execution 20:14)

| # | Item | Result |
|---|---|---|
| 4.1 | job status=SUCCESS | PASS |
| 4.2 | failed=0 | PASS |
| 4.3 | activitiesFailed=0 | PASS |
| 4.4 | stopReasonStats DONE_NO_MORE only | PASS |
| 4.5 | RUNNING job=0 | PASS |
| 4.6 | Redis backfill lock=0 | PASS (no residue this time, vs 4-3D) |
| 4.7 | duplicate=0 | PASS |
| 4.8 | DISPLAYING=total | PASS (3343=3343) |
| 4.9 | snapshot/operation_state growth | PASS (+23709, matches inserted 23692) |
| 4.10 | admin/counts full growth | PASS (see below) |
| 4.11 | backend health=UP | PASS |

### 4.9/4.10 growth table (vs Phase 4-3B 14:18 baseline)

| Metric | Before | After | Delta | Notes |
|---|---|---|---|---|
| product_snapshot | 10161 | 33870 | **+23709** | matches job inserted 23692 |
| product_operation_state | 10161 | 33870 | +23709 | parallel to snapshot |
| distinctProduct | 8962 | 28978 | +20016 | new activities had 20k+ distinct products |
| DISPLAYING | 3325 | 3343 | +18 | most new products are pending/hidden |
| pendingTotal | 337 | 9228 | +8891 | most new products are pending |
| hiddenTotal | 6499 | 21299 | +14800 | hidden is the dominant state for new products |
| activityTotal | 24 | 24 | 0 | scope-level metric unchanged |

## 5. Critical comparison

| Phase | scope | maxAct | dryRun | confirm | API_ERROR rate | duration | result |
|---|---|---|---|---|---|---|---|
| 4-3 | RECENT_30D | 20 | t | false | 11/20 = 55% | 10 min | dry-run PARTIAL |
| 4-3B | CUSTOM_ACTIVITY_IDS | 5 | f | **true** | 0/5 = 0% | 83s | **real SUCCESS** (+8) |
| 4-3C | RECENT_30D | 10 | t | false | 3/10 = 30% | 3m 11s | dry-run PARTIAL |
| 4-3D | RECENT_30D | 20 | t | false | 12/20 = 60% | 4h 6min | dry-run REGRESSION |
| **4-3E** | **RECENT_30D** | **10** | **f** | **true** | **0/10 = 0%** | **19m 45s** | **real SUCCESS** (+23709) |

## 6. Key observations

- **Real backfill at 10 activities is SAFE**: 0 API_ERROR, 0 lock residue, 0 deadlock.
- **API_ERROR 0% is better than dry-run 30%**: the dry-run rate is a **conservative upper bound**, not a hard ceiling. Real backfill may benefit from retry logic that dry-run doesn't.
- **20k+ new rows in 19m 45s** validates that the 4-3A async infra handles the real write load.
- **DISPLAYING only +18 is expected**: displayRefreshMode=DEFERRED means DISPLAYING projection is done by a separate \ProductDisplayRuleJob\ cron, not by this backfill. New products enter pending/hidden first.
- **No Redis lock residue this time** (vs 4-3D's 2 keys): the \eleaseWithOwner\ path worked correctly for this job.

## 7. Conclusion: PASS

All 9 automated checks green, business data growth matches expected scale, no errors.

**Allowed next phase**: Phase 4-3F
- **Option A**: RECENT_30D maxActivities=20 **real** backfill (with caveat: dry-run 20 had 55-60% API_ERROR, so real may fail)
- **Option B**: RECENT_30D maxActivities=10 real backfill **again** (validate consistency, 0% API_ERROR is stable not lucky)
- **Option C**: RECENT_30D maxActivities=15 real backfill (gradual ramp)
- **Option D**: trigger ProductDisplayRuleJob to project the 8891 new pending products to DISPLAYING/HIDDEN
- **Option E**: ALL_ACTIVITIES full backfill (only if API_ERROR stays at 0%)

**Recommendation**: **Option D first** (trigger display projection) - this will move the
+8891 pending products to either DISPLAYING or HIDDEN based on business rules, and
will give the next phase a meaningful DISPLAYING growth signal. Then Option B
(consistency check), then Option C (gradual ramp).

## 8. Artifacts

- \D:\Projects\SAAS\runtime\phase4-3e-submit.json\ - submit response
- \D:\Projects\SAAS\runtime\phase4-3e-poll.log\ - full polling log
