# Phase 4-6: Single activity serial backfill
# Processes remaining activities: dry-run -> real -> verify -> cooldown -> next

$baseUrl = "http://localhost:8081"
$authFile = "D:\Projects\SAAS\harness\scripts\tmp-auth-header.txt"
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$resultsFile = "D:\Projects\SAAS\harness\scripts\phase46-results.json"

$activities = @("3543332","3558291","3592624","3601935","3676949","3686015","3686016","3749687","3859426","3864871")

# Refresh token
$loginResp = curl.exe -s --max-time 10 -X POST "$baseUrl/api/auth/login" -H "Content-Type: application/json" -d "@D:\Projects\SAAS\harness\scripts\tmp-login.json"
if ($loginResp -match '"token":"([^"]+)"') {
    $token = $Matches[1]
    [System.IO.File]::WriteAllText($authFile, "Authorization: Bearer $token", $utf8NoBom)
    Write-Host "Token refreshed"
} else {
    Write-Host "FATAL: Cannot get token"; exit 1
}

$allResults = @()

foreach ($actId in $activities) {
    Write-Host ""
    Write-Host "=========================================="
    Write-Host "Activity: $actId"
    Write-Host "=========================================="

    # --- DRY RUN ---
    $dryRunBody = "{`"scope`":`"CUSTOM_ACTIVITY_IDS`",`"activityIds`":[`"$actId`"],`"pageSize`":20,`"maxActivities`":1,`"maxPagesPerActivity`":2000,`"maxRowsPerActivity`":100000,`"dryRun`":true}"
    $dryFile = "D:\Projects\SAAS\harness\scripts\tmp-dryrun-$actId.json"
    [System.IO.File]::WriteAllText($dryFile, $dryRunBody, $utf8NoBom)

    Write-Host "[DRY] Submitting..."
    $submitResp = curl.exe -s --max-time 15 -X POST "$baseUrl/api/product-sync/admin/backfill-activity-products/async" -H "@$authFile" -H "Content-Type: application/json" -d "@$dryFile"
    
    if ($submitResp -match '"jobId":"([^"]+)"') {
        $dryJobId = $Matches[1]
    } else {
        Write-Host "[DRY] SUBMIT FAILED: $submitResp"
        $allResults += @{ activityId = $actId; dryRunStatus = "SUBMIT_FAILED"; realStatus = "SKIPPED" }
        continue
    }
    Write-Host "[DRY] jobId=$dryJobId, polling..."

    $dryStatus = "RUNNING"
    for ($p = 1; $p -le 80; $p++) {
        Start-Sleep -Seconds 30
        $pollResp = curl.exe -s --max-time 10 "$baseUrl/api/product-sync/admin/backfill-jobs/$dryJobId" -H "@$authFile"
        if ($pollResp -match '"status":"([^"]+)"') { $dryStatus = $Matches[1] }
        $elapsed = $p * 30
        Write-Host "[DRY ${elapsed}s] status=$dryStatus"
        if ($dryStatus -in @("SUCCESS","FAILED","PARTIAL","ABANDONED")) { break }
    }

    # Extract dry-run details
    $dryApiRows = if ($pollResp -match '"apiFetchedRows":(\d+)') { $Matches[1] } else { "0" }
    $dryApiDistinct = if ($pollResp -match '"apiDistinctProductIds":(\d+)') { $Matches[1] } else { "0" }
    $dryStopStats = if ($pollResp -match '"stopReasonStats":(\{[^}]*\})') { $Matches[1] } else { "{}" }
    $dryError = if ($pollResp -match '"errorMessage":"([^"]*)"') { $Matches[1] } else { "" }
    $drySuccess = if ($pollResp -match '"activitiesSuccess":(\d+)') { $Matches[1] } else { "0" }
    $dryFailed = if ($pollResp -match '"activitiesFailed":(\d+)') { $Matches[1] } else { "0" }

    Write-Host "[DRY] FINAL: status=$dryStatus success=$drySuccess failed=$dryFailed apiRows=$dryApiRows apiDistinct=$dryApiDistinct stopStats=$dryStopStats error=$dryError"

    if ($dryStatus -ne "SUCCESS") {
        Write-Host "[DRY] FAILED - skipping real backfill"
        $allResults += @{ activityId = $actId; dryRunStatus = $dryStatus; dryJobId = $dryJobId; dryApiRows = $dryApiRows; dryApiDistinct = $dryApiDistinct; dryStopStats = $dryStopStats; realStatus = "SKIPPED" }
        # Cooldown
        Write-Host "[COOLDOWN] 3 minutes..."
        Start-Sleep -Seconds 180
        continue
    }

    # --- REAL BACKFILL ---
    # Verify no RUNNING and no lock
    $runningCheck = curl.exe -s --max-time 10 "$baseUrl/api/product-sync/admin/backfill-jobs/$dryJobId" -H "@$authFile"
    
    $realBody = "{`"scope`":`"CUSTOM_ACTIVITY_IDS`",`"activityIds`":[`"$actId`"],`"pageSize`":20,`"maxActivities`":1,`"maxPagesPerActivity`":2000,`"maxRowsPerActivity`":100000,`"dryRun`":false,`"confirm`":true,`"displayRefreshMode`":`"DEFERRED`"}"
    $realFile = "D:\Projects\SAAS\harness\scripts\tmp-real-$actId.json"
    [System.IO.File]::WriteAllText($realFile, $realBody, $utf8NoBom)

    Write-Host "[REAL] Submitting..."
    $realSubmit = curl.exe -s --max-time 15 -X POST "$baseUrl/api/product-sync/admin/backfill-activity-products/async" -H "@$authFile" -H "Content-Type: application/json" -d "@$realFile"
    
    if ($realSubmit -match '"jobId":"([^"]+)"') {
        $realJobId = $Matches[1]
    } else {
        Write-Host "[REAL] SUBMIT FAILED: $realSubmit"
        $allResults += @{ activityId = $actId; dryRunStatus = $dryStatus; dryJobId = $dryJobId; dryApiRows = $dryApiRows; dryApiDistinct = $dryApiDistinct; realStatus = "SUBMIT_FAILED" }
        continue
    }
    Write-Host "[REAL] jobId=$realJobId, polling..."

    $realStatus = "RUNNING"
    for ($p = 1; $p -le 80; $p++) {
        Start-Sleep -Seconds 30
        $realPoll = curl.exe -s --max-time 10 "$baseUrl/api/product-sync/admin/backfill-jobs/$realJobId" -H "@$authFile"
        if ($realPoll -match '"status":"([^"]+)"') { $realStatus = $Matches[1] }
        $elapsed = $p * 30
        Write-Host "[REAL ${elapsed}s] status=$realStatus"
        if ($realStatus -in @("SUCCESS","FAILED","PARTIAL","ABANDONED")) {
            $pollResp = $realPoll
            break
        }
    }

    $realInserted = if ($pollResp -match '"inserted":(\d+)') { $Matches[1] } else { "0" }
    $realUpdated = if ($pollResp -match '"updated":(\d+)') { $Matches[1] } else { "0" }
    $realFailed = if ($pollResp -match '"failed":(\d+)') { $Matches[1] } else { "0" }
    $realApiRows = if ($pollResp -match '"apiFetchedRows":(\d+)') { $Matches[1] } else { "0" }
    $realApiDistinct = if ($pollResp -match '"apiDistinctProductIds":(\d+)') { $Matches[1] } else { "0" }
    $realStopStats = if ($pollResp -match '"stopReasonStats":(\{[^}]*\})') { $Matches[1] } else { "{}" }
    $realError = if ($pollResp -match '"errorMessage":"([^"]*)"') { $Matches[1] } else { "" }
    $realSuccess = if ($pollResp -match '"activitiesSuccess":(\d+)') { $Matches[1] } else { "0" }
    $realFailedAct = if ($pollResp -match '"activitiesFailed":(\d+)') { $Matches[1] } else { "0" }

    Write-Host "[REAL] FINAL: status=$realStatus success=$realSuccess failed=$realFailedAct inserted=$realInserted updated=$realUpdated apiRows=$realApiRows apiDistinct=$realApiDistinct stopStats=$realStopStats error=$realError"

    $allResults += @{
        activityId = $actId
        dryRunStatus = $dryStatus
        dryJobId = $dryJobId
        dryApiRows = $dryApiRows
        dryApiDistinct = $dryApiDistinct
        realStatus = $realStatus
        realJobId = $realJobId
        realInserted = $realInserted
        realUpdated = $realUpdated
        realFailed = $realFailed
        realApiRows = $realApiRows
        realApiDistinct = $realApiDistinct
        realStopStats = $realStopStats
    }

    # Cooldown 3 minutes
    Write-Host "[COOLDOWN] 3 minutes before next activity..."
    Start-Sleep -Seconds 180
    
    # Refresh token every 3 activities (token expires in 2h)
    if ($allResults.Count % 3 -eq 0) {
        $loginResp = curl.exe -s --max-time 10 -X POST "$baseUrl/api/auth/login" -H "Content-Type: application/json" -d "@D:\Projects\SAAS\harness\scripts\tmp-login.json"
        if ($loginResp -match '"token":"([^"]+)"') {
            $token = $Matches[1]
            [System.IO.File]::WriteAllText($authFile, "Authorization: Bearer $token", $utf8NoBom)
            Write-Host "[TOKEN] Refreshed"
        }
    }
}

Write-Host ""
Write-Host "=========================================="
Write-Host "ALL ACTIVITIES COMPLETE"
Write-Host "=========================================="
$allResults | ForEach-Object { Write-Host "$($_.activityId): dryRun=$($_.dryRunStatus) real=$($_.realStatus) inserted=$($_.realInserted) updated=$($_.realUpdated)" }

$allResults | ConvertTo-Json -Depth 3 | Out-File -FilePath $resultsFile -Encoding utf8
Write-Host "Results saved to $resultsFile"
