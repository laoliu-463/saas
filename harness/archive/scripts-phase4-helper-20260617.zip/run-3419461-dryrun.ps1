$loginBody = @{ username = "admin"; password = "admin123" } | ConvertTo-Json
$loginResp = Invoke-RestMethod -Uri "http://localhost:8081/api/auth/login" -Method POST -ContentType "application/json" -Body $loginBody
$token = $loginResp.data.token
Write-Host "Login OK, token length: $($token.Length)"

$headers = @{
    Authorization = "Bearer $token"
    "Content-Type" = "application/json"
}

$body = @{
    scope = "CUSTOM_ACTIVITY_IDS"
    activityIds = @("3419461")
    pageSize = 20
    maxActivities = 1
    maxPagesPerActivity = 2000
    maxRowsPerActivity = 100000
    dryRun = $true
} | ConvertTo-Json -Depth 3

Write-Host "Submitting dry-run for 3419461..."
$submitResp = Invoke-RestMethod -Uri "http://localhost:8081/api/product-sync/admin/backfill-activity-products/async" -Method POST -Headers $headers -Body $body

Write-Host "Submit response:"
$submitResp | ConvertTo-Json -Depth 3

if ($submitResp.code -ne 200) {
    Write-Host "SUBMIT FAILED: code=$($submitResp.code) msg=$($submitResp.msg)"
    exit 1
}

$jobId = $submitResp.data.jobId
Write-Host "jobId: $jobId"
Write-Host "Polling every 30s..."

$pollHeaders = @{ Authorization = "Bearer $token" }
for ($i = 1; $i -le 80; $i++) {
    Start-Sleep -Seconds 30
    $statusResp = Invoke-RestMethod -Uri "http://localhost:8081/api/product-sync/admin/backfill-jobs/$jobId" -Headers $pollHeaders
    $d = $statusResp.data
    $elapsed = $i * 30
    Write-Host "[${elapsed}s] status=$($d.status) scanned=$($d.activitiesScanned) success=$($d.activitiesSuccess) failed=$($d.activitiesFailed) apiRows=$($d.apiFetchedRows) inserted=$($d.inserted) updated=$($d.updated) stopStats=$($d.stopReasonStatsJson) error=$($d.errorMessage)"

    if ($d.status -in @("SUCCESS","FAILED","PARTIAL","ABANDONED")) {
        Write-Host ""
        Write-Host "=== FINAL ==="
        Write-Host "jobId: $jobId"
        Write-Host "status: $($d.status)"
        Write-Host "scanned: $($d.activitiesScanned)"
        Write-Host "success: $($d.activitiesSuccess)"
        Write-Host "failed: $($d.activitiesFailed)"
        Write-Host "incomplete: $($d.activitiesIncomplete)"
        Write-Host "apiRows: $($d.apiFetchedRows)"
        Write-Host "apiDistinct: $($d.apiDistinctProductIds)"
        Write-Host "inserted: $($d.inserted)"
        Write-Host "updated: $($d.updated)"
        Write-Host "failedRows: $($d.failed)"
        Write-Host "stopStats: $($d.stopReasonStatsJson)"
        Write-Host "error: $($d.errorMessage)"
        Write-Host "duration: $($d.durationSeconds)s"
        Write-Host "lockWait: $($d.lockWaitCount)"
        Write-Host "deadlock: $($d.deadlockRetryCount)"
        exit 0
    }
}
Write-Host "TIMEOUT after 40 minutes"
exit 2
