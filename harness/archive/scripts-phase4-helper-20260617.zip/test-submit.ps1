try {
    $loginBody = @{ username = "admin"; password = "admin123" } | ConvertTo-Json
    Write-Host "Login body: $loginBody"
    
    $loginResp = Invoke-RestMethod -Uri "http://localhost:8081/api/auth/login" -Method POST -ContentType "application/json" -Body $loginBody
    $token = $loginResp.data.token
    Write-Host "Login OK, token length: $($token.Length)"
} catch {
    Write-Host "LOGIN ERROR: $($_.Exception.Message)"
    exit 1
}

try {
    $headers = @{
        Authorization = "Bearer $token"
        "Content-Type" = "application/json"
    }

    $body = @{
        scope = "CUSTOM_ACTIVITY_IDS"
        activityIds = @("3419461")
        pageSize = 20
        maxActivities = 1
        maxPagesPerActivity = 2000
        maxRowsPerActivity = 100000
        dryRun = $true
    } | ConvertTo-Json -Depth 3

    Write-Host "Submitting dry-run for 3419461..."
    Write-Host "Body: $body"
    $submitResp = Invoke-RestMethod -Uri "http://localhost:8081/api/product-sync/admin/backfill-activity-products/async" -Method POST -Headers $headers -Body $body
    Write-Host "Submit response code: $($submitResp.code)"
    Write-Host "JobId: $($submitResp.data.jobId)"
} catch {
    Write-Host "SUBMIT ERROR: $($_.Exception.Message)"
    exit 1
}
