param([string]$JobId)
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$authHeader = [System.IO.File]::ReadAllText("D:\Projects\SAAS\harness\scripts\tmp-auth-header.txt", $utf8NoBom).Trim()
$baseUrl = "http://localhost:8081"

for ($i = 1; $i -le 80; $i++) {
    Start-Sleep -Seconds 30
    $resp = curl.exe -s --max-time 10 "$baseUrl/api/product-sync/admin/backfill-jobs/$JobId" -H $authHeader
    $respStr = $resp -join ""
    
    $status = if ($respStr -match '"status":"([^"]+)"') { $Matches[1] } else { "UNKNOWN" }
    $scanned = if ($respStr -match '"activitiesScanned":(\d+)') { $Matches[1] } else { "?" }
    $success = if ($respStr -match '"activitiesSuccess":(\d+)') { $Matches[1] } else { "?" }
    $failed = if ($respStr -match '"activitiesFailed":(\d+)') { $Matches[1] } else { "?" }
    $incomplete = if ($respStr -match '"activitiesIncomplete":(\d+)') { $Matches[1] } else { "?" }
    $apiRows = if ($respStr -match '"apiFetchedRows":(\d+)') { $Matches[1] } else { "?" }
    $apiDistinct = if ($respStr -match '"apiDistinctProductIds":(\d+)') { $Matches[1] } else { "?" }
    $inserted = if ($respStr -match '"inserted":(\d+)') { $Matches[1] } else { "?" }
    $updated = if ($respStr -match '"updated":(\d+)') { $Matches[1] } else { "?" }
    $failedRows = if ($respStr -match '"failed":(\d+)') { $Matches[1] } else { "?" }
    $elapsed = $i * 30
    
    Write-Host "[${elapsed}s] status=$status scanned=$scanned success=$success failed=$failed incomplete=$incomplete apiRows=$apiRows apiDistinct=$apiDistinct inserted=$inserted updated=$updated failedRows=$failedRows"
    
    if ($status -in @("SUCCESS","FAILED","PARTIAL","ABANDONED")) {
        Write-Host ""
        Write-Host "=== FINAL ==="
        Write-Host $respStr
        exit 0
    }
}
Write-Host "TIMEOUT after 40 minutes"
exit 2
