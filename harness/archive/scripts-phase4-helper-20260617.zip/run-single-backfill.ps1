param(
    [string]$ActivityId,
    [bool]$DryRun = $true,
    [string]$BaseUrl = "http://localhost:8081"
)

# Login
$loginBody = @{ username = "admin"; password = "admin123" } | ConvertTo-Json
$loginResp = Invoke-RestMethod -Uri "$BaseUrl/api/auth/login" -Method POST -ContentType "application/json" -Body $loginBody
$token = $loginResp.data.token
$headers = @{ Authorization = "Bearer $token"; "Content-Type" = "application/json" }

$mode = if ($DryRun) { "dryRun" } else { "real" }
Write-Host "=== Submit $mode backfill for activity $ActivityId ==="

$body = @{
    scope = "CUSTOM_ACTIVITY_IDS"
    activityIds = @($ActivityId)
    pageSize = 20
    maxActivities = 1
    maxPagesPerActivity = 2000
    maxRowsPerActivity = 100000
    dryRun = $DryRun
    confirm = (-not $DryRun)
    displayRefreshMode = "DEFERRED"
} | ConvertTo-Json -Depth 3

$submitResp = Invoke-RestMethod -Uri "$BaseUrl/api/product-sync/admin/backfill-activity-products/async" -Method POST -Headers $headers -Body $body

if ($submitResp.code -ne 200) {
    Write-Host "SUBMIT FAILED: code=$($submitResp.code) msg=$($submitResp.msg)"
    exit 1
}

$jobId = $submitResp.data.jobId
Write-Host "jobId: $jobId"
Write-Host "Polling every 30s..."

$maxPolls = 80  # 40 minutes
$pollCount = 0
while ($pollCount -lt $maxPolls) {
    Start-Sleep -Seconds 30
    $pollCount++

    $pollHeaders = @{ Authorization = "Bearer $token" }
    $statusResp = Invoke-RestMethod -Uri "$BaseUrl/api/product-sync/admin/backfill-jobs/$jobId" -Headers $pollHeaders

    $d = $statusResp.data
    $status = $d.status
    $scanned = $d.activitiesScanned
    $success = $d.activitiesSuccess
    $failed = $d.activitiesFailed
    $apiRows = $d.apiFetchedRows
    $inserted = $d.inserted
    $updated = $d.updated
    $failedCount = $d.failed
    $stopStats = $d.stopReasonStatsJson
    $errorMsg = $d.errorMessage
    $duration = $d.durationSeconds
    $lockWait = $d.lockWaitCount
    $deadlock = $d.deadlockRetryCount
    $apiDistinct = $d.apiDistinctProductIds
    $incomplete = $d.activitiesIncomplete

    Write-Host "[$($pollCount*30)s] status=$status scanned=$scanned success=$success failed=$failed incomplete=$incomplete apiRows=$apiRows apiDistinct=$apiDistinct inserted=$inserted updated=$updated failedRows=$failedCount stopStats=$stopStats error=$errorMsg duration=${duration}s lockWait=$lockWait deadlock=$deadlock"

    if ($status -eq "SUCCESS" -or $status -eq "FAILED" -or $status -eq "PARTIAL" -or $status -eq "ABANDONED") {
        Write-Host ""
        Write-Host "=== FINAL RESULT ==="
        Write-Host "jobId: $jobId"
        Write-Host "status: $status"
        Write-Host "activitiesScanned: $scanned"
        Write-Host "activitiesSuccess: $success"
        Write-Host "activitiesFailed: $failed"
        Write-Host "activitiesIncomplete: $incomplete"
        Write-Host "apiFetchedRows: $apiRows"
        Write-Host "apiDistinctProductIds: $apiDistinct"
        Write-Host "inserted: $inserted"
        Write-Host "updated: $updated"
        Write-Host "failed: $failedCount"
        Write-Host "stopReasonStats: $stopStats"
        Write-Host "errorMessage: $errorMsg"
        Write-Host "durationSeconds: $duration"
        Write-Host "lockWaitCount: $lockWait"
        Write-Host "deadlockRetryCount: $deadlock"
        exit 0
    }
}

Write-Host "TIMEOUT: job did not complete in 40 minutes"
exit 2
