# Phase 4-7 Pre-check script - using 127.0.0.1
$ErrorActionPreference = "Continue"
$baseUrl = "http://127.0.0.1:8081"

Write-Output "===== 1. Backend Health ====="
try {
    $healthResp = Invoke-WebRequest -Uri "$baseUrl/api/system/health" -UseBasicParsing -TimeoutSec 15
    Write-Output "Health Status: $($healthResp.StatusCode)"
    Write-Output $healthResp.Content
} catch {
    Write-Output "Health ERROR: $($_.Exception.Message)"
}

Write-Output ""
Write-Output "===== 2. Login / Auth ====="
$token = ""
try {
    $loginBody = '{"username":"admin","password":"admin123"}'
    $loginResp = Invoke-WebRequest -Uri "$baseUrl/api/auth/login" -Method POST -Body $loginBody -ContentType "application/json" -UseBasicParsing -TimeoutSec 15
    $loginData = $loginResp.Content | ConvertFrom-Json
    $token = $loginData.token
    if (-not $token -and $loginData.data) { $token = $loginData.data.token }
    if (-not $token) { $token = $loginData.accessToken }
    if (-not $token) {
        # Try to find token in response
        Write-Output "Login response keys: $($loginData | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name)"
        Write-Output "Full response (first 500): $($loginResp.Content.Substring(0, [Math]::Min(500, $loginResp.Content.Length)))"
    }
    if ($token) { Write-Output "Login OK, token length: $($token.Length)" }
} catch {
    Write-Output "Login ERROR: $($_.Exception.Message)"
}

if (-not $token) {
    Write-Output "FATAL: No token, cannot proceed"
    exit 1
}

$headers = @{ "Authorization" = "Bearer $token" }

Write-Output ""
Write-Output "===== 3. RUNNING Jobs (via DB query API or list endpoint) ====="
try {
    # Try listing recent jobs
    $jobsResp = Invoke-WebRequest -Uri "$baseUrl/api/product-sync/admin/backfill-jobs" -Headers $headers -UseBasicParsing -TimeoutSec 15
    Write-Output "Jobs Status: $($jobsResp.StatusCode)"
    Write-Output $jobsResp.Content.Substring(0, [Math]::Min(2000, $jobsResp.Content.Length))
} catch {
    Write-Output "Jobs query ERROR: $($_.Exception.Message)"
}

Write-Output ""
Write-Output "===== 4. Products API Baseline ====="
try {
    $prodResp = Invoke-WebRequest -Uri "$baseUrl/api/products?page=1&size=10" -Headers $headers -UseBasicParsing -TimeoutSec 15
    Write-Output "Products Status: $($prodResp.StatusCode)"
    $prodData = $prodResp.Content | ConvertFrom-Json
    if ($prodData.data) {
        Write-Output "Products total: $($prodData.data.total)"
    } elseif ($prodData.total) {
        Write-Output "Products total: $($prodData.total)"
    } else {
        Write-Output $prodResp.Content.Substring(0, [Math]::Min(500, $prodResp.Content.Length))
    }
} catch {
    Write-Output "Products ERROR: $($_.Exception.Message)"
}

Write-Output ""
Write-Output "===== 5. Admin Counts ====="
try {
    $countsResp = Invoke-WebRequest -Uri "$baseUrl/api/products/admin/counts" -Headers $headers -UseBasicParsing -TimeoutSec 15
    Write-Output "Admin counts Status: $($countsResp.StatusCode)"
    Write-Output $countsResp.Content
} catch {
    Write-Output "Admin counts ERROR: $($_.Exception.Message)"
}

# Save token for later use
$token | Out-File -FilePath "D:\Projects\SAAS\harness\scripts\tmp-phase47-token.txt" -NoNewline
Write-Output ""
Write-Output "Token saved to tmp-phase47-token.txt"
