# Phase 4-7: Submit 3864871 dry-run (async)
$ErrorActionPreference = "Stop"
$baseUrl = "http://127.0.0.1:8081"

# Read token
$token = Get-Content "D:\Projects\SAAS\harness\scripts\tmp-phase47-token.txt" -Raw
$token = $token.Trim()
$headers = @{ "Authorization" = "Bearer $token"; "Content-Type" = "application/json" }

$body = @{
    scope = "CUSTOM_ACTIVITY_IDS"
    activityIds = @("3864871")
    pageSize = 20
    maxActivities = 1
    maxPagesPerActivity = 3000
    maxRowsPerActivity = 60000
    dryRun = $true
} | ConvertTo-Json -Depth 3

Write-Output "===== Submitting 3864871 dry-run ====="
Write-Output "Body: $body"
Write-Output ""

try {
    $resp = Invoke-WebRequest -Uri "$baseUrl/api/product-sync/admin/backfill-activity-products/async" -Method POST -Body $body -Headers $headers -UseBasicParsing -TimeoutSec 30
    Write-Output "Submit Status: $($resp.StatusCode)"
    Write-Output "Response: $($resp.Content)"
} catch {
    $statusCode = $_.Exception.Response.StatusCode.value__
    $errorBody = ""
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $errorBody = $reader.ReadToEnd()
    }
    Write-Output "Submit ERROR: Status=$statusCode"
    Write-Output "Error body: $errorBody"
    Write-Output "Exception: $($_.Exception.Message)"
}
